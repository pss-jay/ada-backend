"""File-based storage backend using JSON files.

This is the default backend for local development and Phase 1 deployment.
Data is stored in app/data/ with subdirectories for versions, amendments, and audit.
"""

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from app.services.storage import StorageBackend
from app.core.config import settings

logger = logging.getLogger(__name__)


class FileStorage(StorageBackend):
    """JSON file storage backend."""

    def __init__(self):
        self.base_dir = settings.DATA_DIR
        self.versions_dir = self.base_dir / "versions"
        self.amendments_dir = self.base_dir / "amendments"
        self.audit_dir = self.base_dir / "audit"
        self.users_dir = self.base_dir / "users"
        self.pending_dir = self.base_dir / "pending_changes"

        for d in [self.base_dir, self.versions_dir, self.amendments_dir,
                   self.audit_dir, self.users_dir, self.pending_dir]:
            d.mkdir(parents=True, exist_ok=True)

    # --- Protocols ---

    def load_protocol(self, protocol_id: str) -> Optional[Dict[str, Any]]:
        path = self.base_dir / f"{protocol_id}.json"
        if not path.exists():
            return None
        with open(path) as f:
            return json.load(f)

    def save_protocol(self, protocol_id: str, data: Dict[str, Any]) -> None:
        path = self.base_dir / f"{protocol_id}.json"
        with open(path, "w") as f:
            json.dump(data, f, indent=2, default=str)

    def load_all_protocols(self) -> List[Dict[str, Any]]:
        protocols = []
        for path in sorted(self.base_dir.glob("*.json")):
            if path.name.startswith("test-"):
                continue
            try:
                with open(path) as f:
                    data = json.load(f)
                pid = path.stem
                ej = data.get("extracted_json", {}) or {}
                bd = ej.get("BasicDetails", {}) or {}
                si = ej.get("StudyInfo", {}) or {}
                ts = ej.get("TestSystem", {}) or {}
                # Build summary
                study_no = bd.get("StudyNo", "") or ej.get("StudyNo", "") or pid
                sponsor = bd.get("SponsorName", "") or ""
                species = data.get("species", "") or ts.get("SpeciesStrain", "") or ""
                title = si.get("Objective", "")
                if title and len(title) > 120:
                    title = title[:120] + "..."
                protocols.append({
                    "protocol_id": pid,
                    "study_number": study_no,
                    "title": title or data.get("filename", "Untitled Protocol"),
                    "sponsor": sponsor,
                    "species": species,
                    "status": data.get("status", "unknown"),
                    "filename": data.get("filename", ""),
                    "created_at": data.get("created_at", ""),
                    "updated_at": data.get("updated_at", ""),
                })
            except Exception as e:
                logger.warning(f"Error loading protocol {path}: {e}")
        return protocols

    # --- Versions ---

    def load_versions(self, protocol_id: str) -> List[Dict[str, Any]]:
        path = self.versions_dir / f"{protocol_id}.json"
        if not path.exists():
            return []
        with open(path) as f:
            return json.load(f)

    def save_versions(self, protocol_id: str, versions: List[Dict[str, Any]]) -> None:
        path = self.versions_dir / f"{protocol_id}.json"
        with open(path, "w") as f:
            json.dump(versions, f, indent=2, default=str)

    # --- Amendments ---

    def load_amendments(self, protocol_id: str) -> List[Dict[str, Any]]:
        path = self.amendments_dir / f"{protocol_id}.json"
        if not path.exists():
            return []
        with open(path) as f:
            return json.load(f)

    def save_amendments(self, protocol_id: str, amendments: List[Dict[str, Any]]) -> None:
        path = self.amendments_dir / f"{protocol_id}.json"
        with open(path, "w") as f:
            json.dump(amendments, f, indent=2, default=str)

    # --- Audit Log ---

    def load_audit_log(self, protocol_id: str, limit: int = 50) -> List[Dict[str, Any]]:
        path = self.audit_dir / f"{protocol_id}.json"
        if not path.exists():
            return []
        with open(path) as f:
            log = json.load(f)
        return list(reversed(log[-limit:]))

    def add_audit_entry(self, protocol_id: str, entry: Dict[str, Any]) -> None:
        path = self.audit_dir / f"{protocol_id}.json"
        log = []
        if path.exists():
            with open(path) as f:
                log = json.load(f)
        log.append(entry)
        with open(path, "w") as f:
            json.dump(log, f, indent=2, default=str)

    # --- Users ---

    def load_user(self, username: str) -> Optional[Dict[str, Any]]:
        path = self.users_dir / f"{username}.json"
        if not path.exists():
            return None
        with open(path) as f:
            return json.load(f)

    def save_user(self, user_data: Dict[str, Any]) -> None:
        username = user_data.get("username", "")
        if not username:
            raise ValueError("User data must include a 'username' field")
        path = self.users_dir / f"{username}.json"
        with open(path, "w") as f:
            json.dump(user_data, f, indent=2, default=str)

    def load_all_users(self) -> List[Dict[str, Any]]:
        users = []
        for path in sorted(self.users_dir.glob("*.json")):
            with open(path) as f:
                users.append(json.load(f))
        return users

    # --- Pending Changes ---

    def load_pending_changes(self, protocol_id: str) -> Optional[Dict[str, Any]]:
        path = self.pending_dir / f"{protocol_id}.json"
        if not path.exists():
            return None
        with open(path) as f:
            return json.load(f)

    def save_pending_changes(self, protocol_id: str, changes: Dict[str, Any]) -> None:
        path = self.pending_dir / f"{protocol_id}.json"
        with open(path, "w") as f:
            json.dump(changes, f, indent=2, default=str)

    def delete_pending_changes(self, protocol_id: str) -> None:
        path = self.pending_dir / f"{protocol_id}.json"
        if path.exists():
            path.unlink()
